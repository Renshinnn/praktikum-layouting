package www.smktelkommlg.sch.id

annotation class Parcelize
